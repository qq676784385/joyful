/*
* @Author: binxchen
* @Date:   2017-01-17 17:07:00
* @Last Modified by:   binxchen
* @Last Modified time: 2017-01-17 17:08:14
*/

module.exports = {

    //url
    mongodb:'mongodb://localhost/restful'
}
